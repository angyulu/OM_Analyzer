"""Configuration and default settings."""
