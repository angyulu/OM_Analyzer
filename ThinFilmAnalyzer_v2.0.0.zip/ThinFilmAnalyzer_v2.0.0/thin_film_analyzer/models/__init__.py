"""Data models and entities."""
